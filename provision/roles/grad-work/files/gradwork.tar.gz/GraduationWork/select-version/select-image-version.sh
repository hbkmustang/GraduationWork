#!/bin/bash

curl -u spring-user-read:vagrant -X GET 'http://localhost:8081/service/rest/v1/search/assets?sort=version&repository_name=docker-repo&name.spring-project' \
 | grep " *downloadUrl.*\",$" | awk -F "/manifests/" '{print $2}' | sed -e "s/,$//" -e "s/\"$//"
