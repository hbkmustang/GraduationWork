#!/bin/bash

curl -u spring-user-read:vagrant -X GET 'http://localhost:8081/service/rest/v1/search/assets?group=GW&name=spring-project&sort=version&maven.extension=jar&maven.classifier' \
 | grep "downloadUrl.*spring-project.*jar\",$" | awk -F ' ' '{print $3}' | awk -F 'spring-project' '{print $2}' |  sed -e 's/,$//' -e 's/^"//' -e 's/"$//' -e 's/^\///' -e 's/\/$//' -e 's/\\n/,/'

# wget --user=spring-user --password=vagrant ${urla}
