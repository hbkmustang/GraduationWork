#!/bin/bash

if [ \( -z "$1" \) -o \( -z "$2" \) ]
 then
  echo "Error: Input parameters are not defined. Need - $0 <name_of_instance> <what_to_do>. Exitting."
  exit 1
fi

if [ \( "$2" == "deploy" \) -a \( -z "$3" \) ]
 then
  echo "Error: Third port parameter are not defined for deploy. Need - $0 <name_of_instance> deploy <port_number>. Exitting."
  exit 1
 else
  portnumber=$3
fi

instance=$1
whattodo=$2

repo_host=repo-local.ci-cd.net.ua

cd /usr/local/GraduationWork
devtools_public_ip=`curl ifconfig.co`
devtools_private_ip=`grep '^devtools ' hosts | awk -F ' ' '{print $2}' | awk -F '=' '{print $2}'`

sec-group-rule () {
   input="ip-list"
   while IFS= read -r line
    do
     ansible-playbook aws/instance.yml --vault-password-file aws/vault.pass -e name_of_instance=${instance} -e allow_ip=${line} -t add_allow_ip_sg
   done < "$input"
   ### for home-ip
   # ansible-playbook aws/instance.yml --vault-password-file aws/vault.pass -e name_of_instance=${instance} -e allow_ip=176.36.5.239/32 -t add_allow_ip_sg
   ### for ip devtools
   ansible-playbook aws/instance.yml --vault-password-file aws/vault.pass -e name_of_instance=${instance} -t add_allow_ip_sg -e allow_ip=${devtools_private_ip}/32
   ### for ${instance} to devtools (for Nexus3 repostirory need)
   ipdefine=`grep '^'${instance}' ' hosts | awk -F ' ' '{print $2}' | awk -F '=' '{print $2}'`
   # ansible-playbook aws/instance.yml --vault-password-file aws/vault.pass -e name_of_instance=devtools -t add_allow_ip_sg -e allow_ip=${ipdefine}/32
   ansible-playbook aws/instance.yml --vault-password-file aws/vault.pass -e name_of_instance=devtools -t add_allow_ip_sg -e allow_ip=${ipdefine}/32
}

case ${whattodo} in
 
 create)
   ansible-playbook aws/instance.yml --vault-password-file aws/vault.pass --extra-vars=name_of_instance=${instance} -t create
   ansible-playbook aws/instance.yml --vault-password-file aws/vault.pass --extra-vars=name_of_instance=${instance} -t ip_ansible_ssh   
   sec-group-rule
   ansible-playbook aws/instance.yml --vault-password-file aws/vault.pass --extra-vars=name_of_instance=${instance} -t add_dns
 ;;
 start)
   ansible-playbook aws/instance.yml --vault-password-file aws/vault.pass --extra-vars=name_of_instance=${instance} -t start
   ansible-playbook aws/instance.yml --vault-password-file aws/vault.pass --extra-vars=name_of_instance=${instance} -t ip_ansible_ssh
   ansible-playbook aws/instance.yml --vault-password-file aws/vault.pass --extra-vars=name_of_instance=${instance} -t add_dns
 ;;
 provision)
   # ansible-playbook -i hosts --limit ${instance} provisioning/site.yml -e hostname_var=${instance}
   ansible-playbook -i hosts --limit ${instance} provisioning/site.yml
   # ansible-playbook -i hosts --limit ${instance} install-any-packets/install-any-packets.yml -e 'pktname=telnet,mc'
 ;;
 provision-parallel)
   # ansible-playbook -i hosts --limit 'all:!devtools' provisioning/site.yml -e hostname_var=${instance}
   ansible-playbook -i hosts --limit 'all:!devtools' provisioning/site.yml
   # ansible-playbook -i hosts --limit 'all:!devtools' install-any-packets/install-any-packets.yml -e 'pktname=telnet,mc'
 ;;
 image-build-push)
   ansible-playbook -i hosts --limit ${instance} deployment/site.yml -e repo_host=${repo_host} -t image-build-push -t download --vault-password-file deployment/ansible-vault.pass
 ;;
 deploy)
   if [ -z "$4" ]
    then
     ansible-playbook -i hosts --limit ${instance} deployment/site.yml -e portnum=${portnumber} -e repo_host=${repo_host} -t deploy -t download --vault-password-file deployment/ansible-vault.pass
    else
     ansible-playbook -i hosts --limit ${instance} deployment/site.yml -e portnum=${portnumber} -e repo_host=${repo_host} -e artifact_version=$4 -t deploy -t download --vault-password-file deployment/ansible-vault.pass
   fi
 ;;
 deploy-in-docker)
   ansible-playbook -i hosts --limit ${instance} deployment/site.yml -e repo_host=${repo_host} -t deploy-in-docker -t download --vault-password-file deployment/ansible-vault.pass
 ;;
 deploy-in-docker-repo)
   if [ -z "$3" ]
    then
     ansible-playbook -i hosts --limit ${instance} deployment/site.yml -e repo_host=${repo_host} -t deploy-in-docker-repo --vault-password-file deployment/ansible-vault.pass
    else
     ansible-playbook -i hosts --limit ${instance} deployment/site.yml -e repo_host=${repo_host} -e image_version=$3 -t deploy-in-docker-repo --vault-password-file deployment/ansible-vault.pass
   fi
 ;;
 stop)
   ansible-playbook aws/instance.yml --vault-password-file aws/vault.pass --extra-vars=name_of_instance=${instance} -t del_dns
   ansible-playbook aws/instance.yml --vault-password-file aws/vault.pass --extra-vars=name_of_instance=${instance} -t stop
 ;;
 delete)
   ansible-playbook aws/instance.yml --vault-password-file aws/vault.pass --extra-vars=name_of_instance=${instance} -t delete
 ;;
 *)
    echo $"Usage: $0 <name_of_instance> <{create|start|provision|provision-parallel|image-build-push|deploy|deploy-in-docker|deploy-in-docker-repo|stop|delete}> <portnumer>"
    exit 1
esac
