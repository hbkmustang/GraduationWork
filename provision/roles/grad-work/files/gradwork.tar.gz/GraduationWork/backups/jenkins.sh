#!/bin/bash

# cd /var/lib/jenkins && tar --ignore-failed-read -czpf /usr/local/GraduationWork/backups/var.lib.jenkins.CONF.tar.gz *.xml jobs/*/*.xml ansible/* userContent/* plugins/* \
tar czpf /usr/local/GraduationWork/backups/var.lib.jenkins.tar.gz -C /var/lib/ jenkins
