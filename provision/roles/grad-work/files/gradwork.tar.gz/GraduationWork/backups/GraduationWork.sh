#!/bin/bash

cd /usr/local && tar cfzp usr.local.GraduationWork.tar.gz -C /usr/local GraduationWork
mv /usr/local/usr.local.GraduationWork.tar.gz /usr/local/GraduationWork/backups
