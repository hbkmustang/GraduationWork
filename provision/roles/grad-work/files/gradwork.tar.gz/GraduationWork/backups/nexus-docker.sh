#!/bin/bash

tar cfzp var.lib.docker.volumes.nexus-data.tar.gz -C /var/lib/docker/volumes nexus-data/
